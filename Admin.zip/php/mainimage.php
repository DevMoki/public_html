<section class="main1">
    <div class="container py-5">
        <div class="row py-5">
            <div class="col-lg-5 pt-4 text-center">
            <h1>Your Neighborhood Grocery Store </h1> 
            <button class="btn1">Shop Now!</button>
            </div>
        </div>
    </div>
</section>