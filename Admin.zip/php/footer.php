<section class="footer py-5">
    <div class="container py-5">
        <div class="row">
            <div class="col-lg-9 m-auto text-center">
                <h1>Join Our Lovely NewsLetter</h1>
                <input type="text" class="px-3" placeholder="Enter Your Email">
                <button class="btn2" type="submit">Subscribe</button>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-11">
                <div class="row">
                    <div class="col-lg-3 py-3">
                        <h5 class="pb-3">CUSTOMER CARE</h5>
                        <P>Regular</P>
                        <p>On Time</p>
                        <p>Always Care</p>
                    </div>
                    <div class="col-lg-3 py-3">
                        <h5 class="pb-3">CUSTOMER CARE</h5>
                        <P>Regular</P>
                        <p>On Time</p>
                        <p>Always Care</p>
                    </div>
                    <div class="col-lg-3 py-3">
                        <h5 class="pb-3">CUSTOMER CARE</h5>
                        <P>Regular</P>
                        <p>On Time</p>
                        <p>Always Care</p>
                    </div>
                    <div class="col-lg-3 py-3">
                        <h5 class="pb-3">CUSTOMER CARE</h5>
                        <span><i class="bi bi-facebook"></i></span>
                        <span><i class="bi bi-instagram"></i></span>
                        <span><i class="bi bi-twitter"></i></span>
                        
                    </div>
                </div>

            </div>
        </div>
        <hr>
        <p class="text-center">Copyright 2022 by RHU Team. All Rights Reserved.</p>
    </div>
</section>
