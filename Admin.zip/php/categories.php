<!--          category home page                    -->
<section class="new">
   <div class="container py-5">
       <div class="row pt-5">
           <div class="col-lg-7 m-auto">
               <div class="row text-center">
                   <div class="col-lg-4">
                   <a href="./beverage.php"> <img src="./upload/beverage.png" class="img-luid img-thumbnail img-category" alt="beverage category image"></a>
                    <a href="./beverage.php"><h6>BEVERAGE</h6></a>
                   </div>
                   <div class="col-lg-4">
                    <a href="./bread.php"><img src="./upload/bakery.png" class="img-luid img-thumbnail img-category" alt="Bakery category image"></a>
                   <a href="./bread.php"> <h6>BREAD & BAKERY</h6></a>
                </div>
                <div class="col-lg-4">
                   <a href="./canned.php"> <img src="./upload/canned.png" class="img-luid img-thumbnail img-category " alt="canned category image"></a>
                   <a href="./canned.php"> <h6>CANNED FOOD</h6>  </a>
                </div>
               </div>
           </div>
       </div>
   </div> 
</section>